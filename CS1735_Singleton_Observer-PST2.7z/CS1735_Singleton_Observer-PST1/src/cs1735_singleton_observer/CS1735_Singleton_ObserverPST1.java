package cs1735_singleton_observer;

import java.io.*;
import java.util.Scanner;

/**
 *
 * @author Chris Sheldon
 */



public class CS1735_Singleton_ObserverPST1 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    private static Scanner input = new Scanner(System.in);
    
    
    public static void main(String[] args) throws IOException{
    
        System.out.println("Enter File Name, Defualt file name: (Grades.txt)");
        
        String fileName = input.nextLine();
        
        
        
        int user_selection;
        
        File f = new File(fileName);
        
        if (f.exists() && !f.isDirectory()) { 
            File_MGR.GetInstance(fileName);
            do{
            
                System.out.println("Enter 1 to add grade, 2 to delete all grades, 3 to quit");
                user_selection = input.nextInt();
        
                if(user_selection == 1)
                {
            
                }//add grade to list
                if(user_selection == 2)
                {
            
                }//delete list
            }//exit condition
            while(user_selection != '3');
            
        }//end if
        else
        {
        throw new FileNotFoundException();
        }
        }//end Main
    
    //Looped Print with empty list check
    public static void Print(String data)        
    {
        //for(int i = 0; i < )
        //for(int j = 0; j < data.length(); j++){
            
        }
    
    }
    

