/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filemanagement;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author aquat
 */
public class DisplayHoriz implements Observer, DisplayInterface {
    
    Observable observable;
    private ArrayList<Integer> output;
    
    public DisplayHoriz(Observable observable){
        output = FileManager.getInstance().getAllGrades();
        this.observable = observable;
        observable.addObserver(this);
        System.out.println("AM I HERE?");
    }
    
    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof FileManager){
            FileManager fileManager = (FileManager)o;
            display();
        }
    }
    
    @Override
    public void display(){
        
        System.out.println("==========================================================");
        System.out.println("Display 1");
        
        if(output.size() > 0){
            int sum = 0;
            for(int i = 0; i < output.size(); i++){
                sum += output.get(i);
            }
            System.out.print("Grades Average: " + sum/output.size() + "%");
        }else{
            System.out.println("Grades Cannot be averaged, because no grades available.");
        }
        System.out.println("==========================================================");
        
    }

}
