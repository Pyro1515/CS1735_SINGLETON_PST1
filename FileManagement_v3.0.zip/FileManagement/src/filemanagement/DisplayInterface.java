/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filemanagement;

/**
 *
 * @author aquat
 */
public interface DisplayInterface {
    public void display();
}
