/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package filemanagement;

import java.io.*;
import java.util.ArrayList;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @throws java.io.IOException
 * @author Adam A
 * @author Chris S
 */
public class FileManager  extends Observable {
    
    private static FileManager fileInstance = null;
    //private String filePath = " ";
    private ArrayList<Integer> grades;
    
    private FileManager(){
        grades = new ArrayList<>();
        
//        System.out.println("Enter path: ");
//        filePath = in.nextLine();
        
        File f = new File("Grades.txt"); 
        if(f.exists() && f.isFile()) {
            try {
                LoadGradeData();
            } catch (IOException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            try {
                WriteGradeData();
            } catch (IOException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
   
    }
    
    
    public static FileManager getInstance(){
        if(fileInstance == null){
            fileInstance = new FileManager();

        }
        return fileInstance;
    }
    
    //add grade a grade
    public void addGrade(int grade){
        grades.add(grade);
        try {
            WriteGradeData();
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        setChanged();
        notifyObservers();
    }
    
    //return an Integer, a nullable int in java
    public Integer getFirstGrade(){
        if(grades.size() > 0){
            return grades.get(0);
        }
        return null;
    }
    
    //return the array list of grades
    public ArrayList<Integer> getAllGrades(){
        return grades;
    }
    
    //clear the file
    public void deleteAllGrades(){
        grades.clear();
        try {
            WriteGradeData();
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        setChanged();
        notifyObservers();
    }
    
    //read in grades from text file
    private void LoadGradeData() throws IOException{
        
        BufferedReader inputStream = null;
        System.out.println("Grades.txt");
        grades = new ArrayList<>();
        
        try {
            inputStream = new BufferedReader(new FileReader("Grades.txt"));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                grades.add(Integer.parseInt(temp));
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }//end LoadGradeData
    
    private void WriteGradeData() throws IOException{
        
        File f = new File("Grades.txt"); 
        if(f.exists() && f.isFile()) {
            f.delete();
        }
        
        File file = new File("Grades.txt");
  
        //Create the file
        if (file.createNewFile())
        {
            System.out.println("File is created!");
        } else {
            System.out.println("File already exists.");
        }
        
        FileWriter writer = new FileWriter("Grades.txt");
        int size = grades.size();
        
        for (int i=0;i<size;i++) {
            String str = grades.get(i).toString();
            
            writer.write(str);
            
            //This prevent creating a blank like at the end of the file**
            if(i < size-1) {
                writer.write("\n");
            }
        }
        writer.close();
    
    }//end WriteGradeData
    
}
