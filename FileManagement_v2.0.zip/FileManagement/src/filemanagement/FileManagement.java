/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filemanagement;

import java.util.Scanner;

/**
 *
 * @author Adam A
 * @author Chris S
 */
public class FileManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        FileManager fileManager = FileManager.getInstance();
        int choice;
        boolean isTrue = true;
        
        while(isTrue){
            System.out.println("Enter 1, 2, or 3 to select action: ");
            choice = in.nextInt();

            switch(choice){
                case 1:
                    System.out.println("Enter grade: ");
                    fileManager.addGrade(in.nextInt());
                    break;
                case 2:
                    fileManager.deleteAllGrades();
                    System.out.println("Grades cleared.");
                    break;
                case 3:
                    isTrue = false;
                    break;
                default:
                    System.out.println("Invalid selection, try again.");
                    break;
            }
            
            System.out.println("---------------------------------");
            System.out.println("Done Editing Grades");
        }
    }
    
}
