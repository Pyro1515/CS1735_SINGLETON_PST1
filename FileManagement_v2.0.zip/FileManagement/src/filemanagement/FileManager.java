/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package filemanagement;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @throws java.io.IOException
 * @author Adam A
 * @author Chris S
 */
public class FileManager {
    
    private static FileManager fileInstance = null;
    private String filePath = " ";
    private ArrayList<Integer> grades;
    
    private FileManager(){
        grades = new ArrayList<>();
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter path: ");
        filePath = in.nextLine();
        
        File f = new File(filePath); 
        if(f.exists() && f.isFile()) {
        
        }
   
    }
    
    
    public static FileManager getInstance(){
        if(fileInstance == null){
            fileInstance = new FileManager();

        }
        return fileInstance;
    }
    
    //add grade a grade
    public void addGrade(int grade){
    }
    
    //return an Integer, a nullable int in java
    public Integer getFirstGrade(){
        return null;
    }
    
    //return the array list of grades
    public ArrayList<Integer> getAllGrades(){
        return grades;
    }
    
    //clear the file
    public void deleteAllGrades(){
        
    }
    
    //read in grades from text file
    private void LoadGradeData() throws IOException{
        
        BufferedReader inputStream = null;
        System.out.println("Grades.txt");
        grades = new ArrayList<>();
        
        try {
            inputStream = new BufferedReader(new FileReader("Grades.txt"));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                grades.add(Integer.parseInt(temp));
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }//end LoadGradeData
    
    private void WriteGradeData(ArrayList<Integer> grades) throws IOException{
        
        FileWriter writer = new FileWriter("grades.txt");
        int size = grades.size();
        
        for (int i=0;i<size;i++) {
            String str = grades.get(i).toString();
            
            writer.write(str);
            
            //This prevent creating a blank like at the end of the file**
            if(i < size-1) {
                writer.write("\n");
            }
        }
        writer.close();
    
    }//end WriteGradeData
    
}
