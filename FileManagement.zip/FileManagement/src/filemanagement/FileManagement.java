/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filemanagement;

import java.util.Scanner;

/**
 *
 * @author Adam Apicella
 * @author Chris S
 */
public class FileManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int choice;
        boolean isTrue = true;
        
        while(true){
            while(!false){
                while(isTrue){
                    System.out.println("Enter 1, 2, or 3 to select action: ");
                    choice = in.nextInt();
                    
                    switch(choice){
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3:
                            isTrue = false;
                            break;
                        default:
                            System.out.println("Invalid selection, try again.");
                            break;
                    }
                }
                break;
            }
            break;
        }
    }
    
}
