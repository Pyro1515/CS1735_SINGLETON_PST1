/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package filemanagement;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author Adam A
 * @author Chris S
 */
public class DisplayHoriz implements Observer, DisplayInterface {
    
    Observable observable;
    private ArrayList<Integer> output;
    
    public DisplayHoriz(Observable observable){
        this.observable = observable;
        
        //adds this object to the list of observers
        observable.addObserver(this);
    }
    
    //this method is called by hasChanged() when notifyObservers send notice
    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof FileManager){
            FileManager fileManager = (FileManager)o;
            output = FileManager.getInstance().getAllGrades();
            display();
        }
    }
    
    @Override
    public void display(){
        
        System.out.println("==========================================================");
        System.out.println("Display 2");
        
        if(output.size() > 0){
            int sum = 0;
            for(int i = 0; i < output.size(); i++){
                System.out.print(output.get(i) + "% ");
            }
            System.out.println();
        }else{
            System.out.println("There are no grades available.");
        }
        System.out.println("==========================================================");
        
    }

}
