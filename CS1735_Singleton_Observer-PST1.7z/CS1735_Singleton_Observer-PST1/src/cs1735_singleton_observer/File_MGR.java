package cs1735_singleton_observer;


import java.io.*;
import java.util.ArrayList;


/**
 *
 * @author Chris
 */
public  class File_MGR {

    
    /**
     * 
     * 
     * @param file
     * @throws java.io.IOException
     */
    public static ArrayList GetInstance (String file) throws IOException{
    
    BufferedReader inputStream = null;
    ArrayList<String> data = new ArrayList<>();
    
    try {
            inputStream = new BufferedReader(new FileReader(file));
            String temp;
            
            while ((temp = inputStream.readLine()) != null) {
                data.add(temp);
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    return data;
    }
    
    
    
}
